#pragma once
class MeteorMode : public SurviveMode
{
};

