#pragma once

class ObatacleMode : public SurviveMode
{
};

