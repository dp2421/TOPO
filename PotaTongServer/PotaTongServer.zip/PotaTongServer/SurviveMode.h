#pragma once
class SurviveMode : public GameMode
{
};

