#pragma once

class BombMode : public SurviveMode
{
};

