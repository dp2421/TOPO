#pragma once
class GameMode
{
};

