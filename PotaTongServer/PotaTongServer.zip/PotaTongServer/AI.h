#pragma once

class AI
{
public:
	Client client;
};

