#pragma once
#include "Obstacle.h"
class PendulumObs :
    public Obstacle
{
};

