#pragma once
#include "Obstacle.h"
class SpinObs :
    public Obstacle
{
};

