#include "pch.h"

int main()
{
	ServerBase server;
	server.Run();
}